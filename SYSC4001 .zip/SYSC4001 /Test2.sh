gcc -o Assignment2 ./Assignment2.c 
./Assignment2 test_case_2.csv output2.txt