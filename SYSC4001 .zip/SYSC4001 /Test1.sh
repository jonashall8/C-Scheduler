gcc -o PriorityScheduler ./PriorityScheduler.c 
./PriorityScheduler test_case_2.csv output1.txt